# Lotofácil Inteligente — Análise Avançada

Protótipo web para análise estatística e geração de combinações da Lotofácil.

## Modelo avançado
- Frequência recente (30%)
- Atraso (15%)
- Equilíbrio pares/ímpares (20%)
- Repetição do último concurso (15%)
- Distribuição por faixas (10%)
- Pares recorrentes (10%)
- Score de cada jogo
- Janelas de 20, 50 e 100 concursos
- Backtest histórico
- Geração de 5, 10 ou 20 jogos
- Atualização dos resultados via API pública da CAIXA

## Uso
Abra `index.html` em um navegador com internet e toque em “Atualizar resultados da CAIXA”.

## Importante
O modelo não prevê sorteios nem garante 15 pontos. Estatísticas históricas não alteram a probabilidade matemática de uma combinação específica ser sorteada. O aplicativo não realiza apostas.
